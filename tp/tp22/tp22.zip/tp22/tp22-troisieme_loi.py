#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 29 18:57:13 2022
TP22 - Astronomie (partie 2)
@author: remimetzdorff
"""

import numpy as np
import matplotlib.pyplot as plt

a = np.array([]) # À compléter
T = np.array([]) # À compléter

# REPRÉSENTATIONS GRAPHIQUES
plt.figure(1)
plt.plot() # À compléter
plt.show()